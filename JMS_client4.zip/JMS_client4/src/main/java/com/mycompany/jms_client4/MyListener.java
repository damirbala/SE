/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jms_client4;

import java.util.Enumeration;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 *
 * @author biar
 */
public class MyListener implements MessageListener {

    public void onMessage(Message message) {
        TextMessage msg = null;
        try {
//            if (message instanceof TextMessage) {
//                msg = (TextMessage) message;
//                Enumeration e = msg.getPropertyNames();
//
//                Enumeration enumeration = msg.getPropertyNames();
//                if (e != null) {
//                    while (enumeration.hasMoreElements()) {
//                        String key = (String) enumeration.nextElement();
//                        Object value = message.getObjectProperty(key);
//                        if (value.equals("Barilla ")) {
//                            System.out.println("Reading message: " + msg.getText());
//                        }
//                    }
//                }
//
//            } else {
//                System.out.println("Message of wrong type: "
//                        + message.getClass().getName());
//            }
msg = (TextMessage) message;
System.out.println("Reading message: " + msg.getText());
        } catch (JMSException e) {
            System.out.println("JMSException in onMessage(): " + e.toString());
        } catch (Throwable t) {
            System.out.println("Exception in onMessage():" + t.getMessage());
        }
    }

}

