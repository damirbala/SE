/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab_2_client;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 *
 * @author biar
 */
public class Application {
    
    private final static String BASE_URL = "http://localhost:8080/course/";
    
    public static void main(String[] args) throws Exception {
        URL url = new URL(BASE_URL + "courses/1");
        InputStream input = url.openStream();
        Course course
            = JAXB.unmarshal(new InputStreamReader(input), Course.class);
        System.out.println("name:" + course.getName());
        
        Student student = new Student();
        student.setId(3);
        student.setName("Steve");
        student.setSurname("Baltimor");
        
        CloseableHttpClient client = HttpClients.createDefault();;
        HttpPost httpPost = new HttpPost(BASE_URL + "courses/1/students");
        StringWriter sw = new StringWriter();
        JAXB.marshal(student, sw);
        httpPost.setEntity(new StringEntity(sw.toString()));
        
        httpPost.setHeader("Content-Type", "text/xml");
        HttpResponse response = client.execute(httpPost);
        System.out.println("POST executed:" + response.getStatusLine());
    }
}
