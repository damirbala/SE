/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab2_server;

import java.util.Map;
import com.mycompany.lab2_server.models.Course;
import com.mycompany.lab2_server.models.Student;
import com.sun.org.glassfish.gmbal.ParameterNames;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.ws.rs.*;

/**
 *
 * @author biar
 */
@Path("course")
@Produces("text/xml")
public class CourseRepository {
    private Map<Integer, Course> courses = new HashMap<>();
 
    // request handling methods
    
    CourseRepository() {
        Student s1 = new Student();
        Student s2 = new Student();
        
        s1.setId(1);
        s1.setName("Peter");
        s1.setSurname("Parker");
        
        s2.setId(2);
        s2.setName("John");
        s2.setSurname("Smith");
        
        Course course1 = new Course();
        course1.setId(1);
        course1.setName("Software eng.");
        
        List<Student> list1 = new ArrayList<>();
        list1.add(s1);
        list1.add(s2);
        
        course1.setStudents(list1);
        courses.put(1, course1);
    }
 
    private Course findById(int id) {
        for (Map.Entry<Integer, Course> course : courses.entrySet()) {
            if (course.getKey() == id) {
                return course.getValue();
            }
        }
        return null;
    }
    
    @GET
    @Path("courses/{courseId}")
    public Course getCourseById(@PathParam("courseId") int id) {
        return this.findById(id);
    }
    @Path("courses/{courseId}/students")
    public Course pathToCourse(@PathParam("courseId") int id) {
        return this.findById(id);
    }
}
