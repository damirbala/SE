/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab2_server.models;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author biar
 */
@XmlRootElement(name = "Course")
public class Course {
    
    private int id;
    private String name;
    private List<Student> students = new ArrayList<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }
 
    private Student findById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }
    
    @GET
    @Path("{stidentId}")
    public Student getStudentById(@PathParam("stidentId")int id) {
        return this.findById(id);
    }
    
    @POST
    @Path("")
    public Response createNewStudent(Student student) {
        Student s = this.findById(student.getId());
        if (s == null) {
            this.students.add(student);
            return Response.ok(student).build();
            
        } else {
            return Response.status(Response.Status.CONFLICT).build();
        }
    }
    
    
}
